package com.example.KT_Giua_Ky;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KtGiuaKyApplicationTests {

	@Test
	void contextLoads() {
	}

}
