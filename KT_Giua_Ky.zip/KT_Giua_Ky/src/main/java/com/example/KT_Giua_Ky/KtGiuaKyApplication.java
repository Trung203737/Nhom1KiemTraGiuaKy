package com.example.KT_Giua_Ky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtGiuaKyApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtGiuaKyApplication.class, args);
	}

}
